package packageThree;

public class protectedModifier {
	
	protected void protectedModifiermethod() {
		System.out.println("This is Protected method.");
	}

}
