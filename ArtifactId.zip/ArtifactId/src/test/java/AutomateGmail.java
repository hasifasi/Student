import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class AutomateGmail {
	WebDriver driver;
	@Test
	public void launchGmail() {
	
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") +"/"+"Driver"+"\\"+"chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		//driver.get("http://demo.guru99.com/test/login.html");		
		//Loginpage();
		
		
		driver.get("http://demo.guru99.com/test/table.html");
		fetchTableData();
		
	}
	
	public void Loginpage() {
		
		driver.findElement(By.id("email")).sendKeys("sdfsdfs");
		
		//driver.findElement(By.xpath("//*[@id='email']")).sendKeys("DASfd");
		
		driver.findElement(By.xpath("//*[@id='passwd']")).sendKeys("sdfsdfd");
		
		driver.findElement(By.xpath("//*[@id='SubmitLogin']")).click();
		//String S=driver.findElement(By.xpath("//*[text()='Successfully Logged in...')]")).getText();
		String S=driver.findElement(By.xpath("//*[contains(text(),'Successfully')]")).getText();
		
		
		if(S.equalsIgnoreCase("Successfully Logged in...")){
			System.out.println("Test is pass");
		}else {
			System.out.println("Test is failed");
		}
	}
	
	public void fetchTableData() {
		
		WebElement table= driver.findElement(By.xpath("/html/body/table"));
		
		List rows= table.findElements(By.xpath("/html/body/table/tbody/tr"));
		
		int R=rows.size();
		
		System.out.println("row count is "+R);
		
		for(int i=1;i<=R;i++) {
			List columns = table.findElements(By.xpath("/html/body/table/tbody/tr["+i+"]/td"));
			int C= columns.size();
			for(int j=1;j<=C;j++) {
				String V=driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td["+j+"]")).getText();
				System.out.println(V);
			}
	
		}
	}

}
