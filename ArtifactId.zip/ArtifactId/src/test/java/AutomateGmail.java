import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class AutomateGmail {
	
	@Test
	public void launchGmail() {
	
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") +"/"+"Driver"+"\\"+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("http://www.mail.yahoo.com");
		
		
		
		
		
		
	}

}
