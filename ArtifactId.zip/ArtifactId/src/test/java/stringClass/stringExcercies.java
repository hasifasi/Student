package stringClass;

public class stringExcercies {

	public static void main(String[] args) {
		//stringsExamples();
		
		//stringContact();
		//substringEX();
		
		//stringBuff();
		
		palindromeReverse();

	}
	
	public static void stringsExamples() {
		
		String A= "Hello";
		String B= "World";
		String C= "Ha";
		String D= "HELLO";
		
//		System.out.println(A.compareTo(B));
//		
//		System.out.println(A.compareTo(C));
		
		if(A.equals(D)) {
			System.out.println("Both are same");
		}else {
			System.out.println("Both are different");
		}
		
		if(A.equalsIgnoreCase(D)) {
			System.out.println("Both are same");
		}else {
			System.out.println("Both are different");
		}
		
	}
	
	public static void stringContact() {
		String A= "Hello";
		String B= "Java";
		
		 String C=A.concat(B);
		 System.out.println(A);
		 System.out.println(C);
	}
	
	public static void substringEX() {
		String Z="Knowledge";
		
		System.out.println(Z.substring(5));
		
		System.out.println(Z.substring(3, 5));
	}
	
	public static void stringBuff() {
		
		String A="Moon";
		StringBuffer Bf= new StringBuffer(A);
		Bf.insert(3,"k");
		
		//System.out.println(Bf);
		
	System.out.println(Bf.append("light"));
		
		
	}
	
	public static void palindromeReverse() {
		String A="Malayalam";
		StringBuilder SB = new StringBuilder(A);
		
		String C=SB.reverse().toString();
		
		
		if(A.equalsIgnoreCase(C)){
			System.out.println("Yes it is Palindrome");
		}else {
			System.out.println("It is not Palindrome");
		}
	}
	

}
