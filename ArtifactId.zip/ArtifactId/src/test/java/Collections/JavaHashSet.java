package Collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;


public class JavaHashSet {
	
public static void main(String[] args){
	hashSetEx();
	
	//treeSetEx();
		
	}

public static void hashSetEx() {
	
	HashSet HS = new HashSet();
	
	HS.add(3);
	HS.add(5);
	HS.add(2);
	HS.add(1);
	HS.add(33);
	HS.add(2);
	//HS.add("Test");
	
	Iterator L= HS.iterator();
	
	while(L.hasNext()) {
		System.out.println(L.next());
	}
}

public static void treeSetEx() {
	TreeSet T= new TreeSet();
	
	T.add(3);
	T.add(1);
	T.add(44);
	T.add(2);
	T.add(0);
	T.add(100);
	T.add(100);
	
	
	Iterator TI = T.iterator();
	while(TI.hasNext()) {
		System.out.println(TI.next());
	}
	
}

public static void setInterfaceEx() {
	Set<Integer> S= new HashSet<Integer>();
	
	
	S.add(4);
	S.add(3);
	S.add(6);
	
//	for(int i=0;i<S.size();i++) {
//		System.out.println(S.g);
//	}
	
	for(int i:S) {
		System.out.println(i);
	}
}
	
	
}
