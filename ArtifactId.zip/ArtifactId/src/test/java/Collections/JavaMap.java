package Collections;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

// Key -  value pair
public class JavaMap {
	
	public static void main(String arg[]) {
		hashmapex();
	}
	
	public static void hashmapex() {
		HashMap<String,String> HM= new HashMap<String,String>();
		
		HM.put("Name", "Ford");
		HM.put("Type", "Car");
		HM.put("Model","ERER");
		
//		Option1
//		System.out.println(HM.get("Name"));
//		System.out.println(HM.get("Model"));
		
//		Option2
//		Set Smap= HM.keySet();
//		
//		for(Object S:Smap) {
//			System.out.println(HM.get(S));
//		}
		
//		Option3
		for(Map.Entry m:HM.entrySet()){
			System.out.println(m.getKey()+"-----"+m.getValue());
		}
		
	}
	
	public static void tableEx() {
		Hashtable<String,String> HT = new Hashtable<String,String>();
		
		HT.put("Name", "Sandy");
		HT.put("Location", "SFO");
		
	}

}
