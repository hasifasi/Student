package Collections;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class JavaArray {
	
	public static void main(String args[]) {
		//arrayExcercise();
		arrayListEx();
		//linkedList();
	}
	
	public static void arrayExcercise() {
		int[] A = new int[3]; // syntax
//		String[] S= new String[3];
//		S[0]="Test";
//		or		
//		int B[]= new int[3];
		
		
		A[0]=10;
		A[1]=20;
		A[2]=30;
		
		System.out.println("Array Lenght " +A.length);
		int K=A.length;
		
		for(int i=0;i<K;i++) {
		System.out.println(A[i]);	
		}
		
		
	}
	
	public static void arrayListEx() {
		ArrayList<Integer> C= new ArrayList<Integer>(); //syntax
		
		C.add(4);
		C.add(5);
		C.add(6);
		C.add(88);
		C.add(6);
		
		for(int i=0;i<C.size();i++) {
			System.out.println(C.get(i));
		}
		
	}
	
	public static void linkedList() {
		LinkedList<String> S= new LinkedList<String>();
		LinkedList<String> K= new LinkedList<String>();
		
		S.add("Test1");
		S.add("Test2");
		S.add("Test3");
		//S.add(2, "TEst");
		
		K.add("Test4");
		
		S.addAll(K);
		
		
		
		for(int i=0;i<S.size();i++) {
			System.out.println(S.get(i));
		}
		
	}
	
	public static void listInterfaceExample() {
		//List L= new ArrayList();
		List<Integer> L = new LinkedList<Integer>();
		
		L.add(3);
		L.add(5);
		
	}
	
	
	
	

}
