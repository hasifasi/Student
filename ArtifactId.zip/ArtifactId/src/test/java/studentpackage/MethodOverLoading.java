package studentpackage;

public class MethodOverLoading {
	
	public int addition(int a,int b) {
		int result= a+b;
		return result;
	}
	
	public int addition(int a,int b,int c) {
		int result= a+b+c;
		return result;
	}
	
	

}
