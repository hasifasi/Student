package studentpackage;

import APItest.TestAPI;
import packageThree.protectedModifier;
import packageTwo.AccModifiers;


public class Modifiers extends protectedModifier{

	public static void main(String[] args) {
	
		//ACCESS MODIFIERS**************
		/*
		 * AccessModifiers A= new AccessModifiers();
		 * 
		 * //A.methodPrivate(); A.methodDefault();
		 * 
		 * AccModifiers B= new AccModifiers(); //B.methodDefaultfromDiffPackage();
		 * 
		 * Modifiers C = new Modifiers(); C.protectedModifiermethod();
		 */
		
		
		//CONSTRUCTORS**********
		
//		
//		Contructors A= new Contructors(1,"Sundar");
//		Contructors B= new Contructors(2, "Suresh");
//		
//		A.show1();
//		B.show1();
		
		// API Automation
		TestAPI A= new TestAPI();
		//A.methodGet();
		//A.methodPost();
		
		
		//Inheritance
		InheritanceChild I= new InheritanceChild();
		
		System.out.println(I.Cinteger +" "+I.Cstring);
		I.methodChild();
		I.start();
			
		System.out.println(I.Pinteger+" "+I.Pstring);
		I.methodParent();
		
		//Methodoverload
		MethodOverLoading M= new MethodOverLoading();
		int R=M.addition(4, 5);
		System.out.println(R);
		
	}
	
	

}
