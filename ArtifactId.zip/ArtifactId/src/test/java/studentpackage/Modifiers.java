package studentpackage;

import APItest.TestAPI;
import packageThree.protectedModifier;
import packageTwo.AccModifiers;


public class Modifiers extends protectedModifier{

	public static void main(String[] args) {
	
		//ACCESS MODIFIERS**************
		/*
		 * AccessModifiers A= new AccessModifiers();
		 * 
		 * //A.methodPrivate(); A.methodDefault();
		 * 
		 * AccModifiers B= new AccModifiers(); //B.methodDefaultfromDiffPackage();
		 * 
		 * Modifiers C = new Modifiers(); C.protectedModifiermethod();
		 */
		
		
		//CONSTRUCTORS**********
		
//		
//		Contructors A= new Contructors(1,"Sundar");
//		Contructors B= new Contructors(2, "Suresh");
//		
//		A.show1();
//		B.show1();
		
		// API Automation
		//TestAPI A= new TestAPI();
		//A.methodGet();
		//A.methodPost();
		
		
		//Inheritance
//		InheritanceChild I= new InheritanceChild();
//		
//		System.out.println(I.Cinteger +" "+I.Cstring);
//		I.methodChild();
//		I.start();
//			
//		System.out.println(I.Pinteger+" "+I.Pstring);
//		I.methodParent();
		
		//Methodoverload
//		MethodOverLoading M= new MethodOverLoading();
//		int R=M.addition(4, 5);
//		System.out.println(R);
		
		
//		FINAL KEYWORD
		/*FinalKeyword fk= new FinalKeyword();
		fk.finaluse();
		
		Abc v= new xyc();
		v.show();
		
		efg b= new xyc();
		b.move();*/
		
//		Encapsu E=new Encapsu();
//		E.setI(4);
//		System.out.println(E.getI());
		
		// RUNTIME POLYMORPHISM
		/*Rectangle R= new Rectangle();
		R.draw();
		
		Circle C= new Circle();
		C.draw();
		
		Triangle T = new Triangle();
		T.draw();
		System.out.println("+++++++++UP CASTING+++++++++++++++++++++");
		RuntimeShape S;
		S= new Rectangle();
		S.draw();
		S= new Circle();
		S.draw();
		S= new Triangle();
		S.draw();*/
		
		//Encapsulation
		Encapsulation E= new Encapsulation();
		E.setI(5);
		
		System.out.println(E.getI());
	}
	
	

}
