package studentpackage;

import packageThree.protectedModifier;
import packageTwo.AccModifiers;


public class Modifiers extends protectedModifier{

	public static void main(String[] args) {
	
		//ACCESS MODIFIERS**************
		/*
		 * AccessModifiers A= new AccessModifiers();
		 * 
		 * //A.methodPrivate(); A.methodDefault();
		 * 
		 * AccModifiers B= new AccModifiers(); //B.methodDefaultfromDiffPackage();
		 * 
		 * Modifiers C = new Modifiers(); C.protectedModifiermethod();
		 */
		
		
		//CONSTRUCTORS**********
		
		
		Contructors A= new Contructors(1,"Sundar");
		Contructors B= new Contructors(2, "Suresh");
		
		A.show1();
		B.show1();
		
		
	}
	
	

}
