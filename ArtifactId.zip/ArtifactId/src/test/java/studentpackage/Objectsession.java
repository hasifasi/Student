package studentpackage;

public class Objectsession {
	
	int b=30; // Instance variable will be inside Class but outside Method
	
	 static int c=40; // static keyword to be used before instance variable

	public static void main(String[] args) {
//		method1();
//		
//		classTwo obecj1= new classTwo();
//		obecj1.method2();
//		
//		System.out.println(c);		
//		obecj1.sum();
//		obecj1.diff();		
//		c=30;
//		 System.out.println(c);
		
		controlstatements object2= new controlstatements();
		
		//object2.methodif();
		//object2.methodladderif();
		//object2.methodSwitch();
		//object2.methodFor();
		//object2.methodWhile();
		object2.methodDoWhile();
		

	}
	
	public static void method1() {
		
		int a=20; // Local variable will be inside Methods
		
		System.out.println("This is Method1");
		
		
		
	}

}
