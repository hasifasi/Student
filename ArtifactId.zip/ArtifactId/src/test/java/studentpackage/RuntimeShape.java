package studentpackage;

public class RuntimeShape {

	void draw(){System.out.println("drawing...");}  
	}  

	class Rectangle extends RuntimeShape{  
	void draw(){System.out.println("drawing rectangle...");}  
	}  
	
	class Circle extends RuntimeShape{  
	void draw(){System.out.println("drawing circle...");}  
	}  
	
	class Triangle extends RuntimeShape{  
	void draw(){System.out.println("drawing triangle...");}  
	}  
	
	

		
		
		
