package studentpackage;

public class Encapsulation {
	
private	int i;

public int getI() {
	System.out.println("THis is used");
	return i;
}

public void setI(int i) {
	this.i = i;
}


}
