package studentpackage;

public class InheritanceParent {
	
	int Pinteger=555;
	final String Pstring="Tester";
	
	InheritanceParent(){
		System.out.println("Parent constructor");
	}
	
	public void methodParent() {
		System.out.println("Inside Parent method");
	}
	
	public void start() {
		
		System.out.println("inside parent start");
	}

}
