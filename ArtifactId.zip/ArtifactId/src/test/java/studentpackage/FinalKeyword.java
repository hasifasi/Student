package studentpackage;

public class FinalKeyword {
	
	final static int A=3;
	
	public void finaluse() {
		//A=4;
		System.out.println(A);
	}
	

}
