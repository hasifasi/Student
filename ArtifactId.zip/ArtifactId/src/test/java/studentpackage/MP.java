package studentpackage;

public abstract class MP {
	
	public void call() {
		System.out.println("calling...");
	}
	
	public abstract void move();
	public abstract void dance();

}


abstract class  RP extends MP{
	public void move() {
		System.out.println("moving..");
	}
}

 class  KP extends RP{
	public void dance() {
		System.out.println("dancing..");
	}}
 
 
 
 
 
 interface Abc{
	 void show();
 }
 
 interface efg{
	 void move();
 }
 
 class xyc implements Abc,efg{
	public void show() {
		System.out.println("showing..");
	}
	 
	public void move() {
		System.out.println("moving..");
	}
 }
 
 
 class Encapsu{
	 private int i;

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}
	 
 }
 
 