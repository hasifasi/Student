package studentpackage;

public abstract class OrangePhone {
	
	public void call() {
		System.out.println("Calling");
	}
	
	public abstract void vibrate();
	public abstract void singing();

}

    abstract class OrangePhoneV1 extends OrangePhone{
	 
	 public void vibrate() {
		 System.out.println("Vibrating..");
	 }
	 	
}

    class OrangePhoneV2 extends OrangePhoneV1{
    	public void singing() {
   		 System.out.println("singing");
   	 }
    }