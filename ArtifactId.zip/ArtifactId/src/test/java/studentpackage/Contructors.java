package studentpackage;

public class Contructors {
	// this can be referred as current class instance variable
	
	int id;
	String name;
	static String college = "Anna Univ";
	
	Contructors(int id,String name){
		System.out.println("This is Constructors");
		this.id=id;
		this.name=name;
		
	}
	
	void show() {
		System.out.println(id+"  "+name+"  "+college);
	}
	
	void show1() {
		System.out.println("This is inside show1");
		show();
	}
	
	

}
