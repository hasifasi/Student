package studentpackage;

public class controlstatements {
	
	public void methodif() {
		
		int n=101;
		
		if(n<=100) {
			System.out.println("The value of n is lesser than 100");
		}else {
			System.out.println("The value n is greater than 100");
		}
	}
	
	public void methodladderif() {
		
		int n=11;
		
		if(n==10) {
			System.out.println("This is value n");
		}else if(n<10){
			System.out.println("Lesser than 10");
		}else {
			System.out.println("Greater than 10");
		}
	}
	
	public void methodSwitch() {
		int n=11;
		switch (n){
		case 10:
			System.out.println("This is the one");
			break;
		case 3:
			System.out.println("This is the Two");
			break;
		
		default :
			System.out.println("Nothing met");
		}
		
	}
	
	public void methodFor() {
		int i;
		for(i=0;i<=5;i++) {
			System.out.println("This is for loop");
		}
		
	}
	
	public void methodWhile() {
		int i=0;
		while(i<6) {
			System.out.println("This is while loop");
			i++;
		}
	}
	
	public void methodDoWhile() {
		int i=0;
		do {
			System.out.println("This is Do-while loop");
			i++;
		}while(i<4);
		
	}

}
