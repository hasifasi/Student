package studentpackage;

public class classTwo {
	
	int b=30;
	
	public void method2() {
		
		int a=20;
		
		System.out.println("This is Method2");
	}
	
	public void sum() {
		int n1= 20; // local variable
		
		int sum = n1+b;
		
		System.out.println(sum);
	}
	
	public void diff() {
		int n2=100;
		
		int diff= n2-b;
		
		System.out.println(diff);
	}

}
