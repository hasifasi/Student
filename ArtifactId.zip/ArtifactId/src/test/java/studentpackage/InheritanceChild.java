package studentpackage;

public class InheritanceChild extends InheritanceParent{
	
	int Cinteger=666;
	String Cstring="John";
	
	InheritanceChild(){
		super();
	}
	
	
	public void methodChild() {
		System.out.println("Inside child method");
	}
	
	public void start() {
		System.out.println("inside child start");
	}
	
	public void superMethod() {
		
		System.out.println(super.Pinteger);
		super.methodParent();
		
	}
	
	

	
}
