package studentpackage;

public class AccessModifiers  extends Contructors{

	

	private void methodPrivate() {
		System.out.println("This is Private method");
	}
	
	void methodDefault() {
		System.out.println("This is Default Method");
	}
	
	String a=Contructors.college;
	Contructors k= new Contructors();
	


}
