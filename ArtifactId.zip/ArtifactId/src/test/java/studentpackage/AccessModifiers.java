package studentpackage;

public class AccessModifiers {

	private void methodPrivate() {
		System.out.println("This is Private method");
	}
	
	void methodDefault() {
		System.out.println("This is Default Method");
	}
	
}
