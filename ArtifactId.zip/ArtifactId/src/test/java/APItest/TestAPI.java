package APItest;

import org.json.simple.JSONObject;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class TestAPI {
	
	public void methodGet() {
		System.out.println("Im in API");
		Response R= RestAssured.get("http://localhost:3000/employees123");
		
		System.out.println(R.getStatusCode());
		
		String B= R.asString();
		
		System.out.println(B);
		 
	}
	
	public void methodPost() {
		
		RequestSpecification R=RestAssured.given();
		
		R.header("Content-Type","application/json");
		
		JSONObject J= new JSONObject();
		
		J.put("id",17);
		J.put("first_name","Tester");
		J.put("last_name","QA");
		J.put("email","QA@gmail.com");
		
		R.body(J.toString());
		
		
		Response Resp= R.post("http://localhost:3000/employees123");
		
		//System.out.println(Resp.getStatusCode());
		int code= Resp.getStatusCode();
		
		if(code==201) {
			System.out.println("Successfully inserted");
		}else {
			System.out.println("Issue occurred "+code);
		}
		
		
	}

}
