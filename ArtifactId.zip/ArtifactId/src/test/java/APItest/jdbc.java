package APItest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class jdbc {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		 jdbcConnecion("select column2 from table where Column='value'");
	}
	
	
	// Driver name
	// Make a connection using URL, UsrId and password
	// Create statement
	// Execute the query
	
	public static void jdbcConnecion(String Query) throws ClassNotFoundException, SQLException {
		Class.forName("com.ibm.db2.jcc.DB2Driver");
		
		Connection con = DriverManager.getConnection("jdbc:db2://db2claima.iso.com:3323/ISONA", "USERID", "Password");
		
		Statement st = con.createStatement();
		ResultSet Rs= st.executeQuery(Query);
		
		//return Rs;
		if (Rs.next()) {
			System.out.println(Rs.getString("columnName"));
		}
		
	}

}
