package APItest;

import java.util.TreeSet;

public class So1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 1, 10, 2, -10, -20 }; 
		segregate(arr, arr.length);
	}

	
	static int segregate(int arr[], int size) 
    { 
        int j = 0, i; 
        for (i = 0; i < size; i++) { 
            if (arr[i] <= 0) { 
                int temp; 
                temp = arr[i]; 
                arr[i] = arr[j]; 
                arr[j] = temp; 
                // increment count of non-positive 
                // integers 
                j++; 
            } 
        } 
  
        return j; 
    } 
}


