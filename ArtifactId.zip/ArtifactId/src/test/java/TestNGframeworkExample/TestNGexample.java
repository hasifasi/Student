package TestNGframeworkExample;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;



//Junit framework --> TestNG framework
// Add TestNG maven dependency in POM.xml
public class TestNGexample {
	
	// Before Suite 
		// Before Class
			// Before Method
				//Test
			//After Method
		//After Class
	//After Suite
	@Test
	public void bcd() {
		System.out.println("This is TestNG Test");
	
	}
	 
	@AfterClass
	public void svsdd() {
		System.out.println("This is TestNG Afterclass");
	
	}
	
	@BeforeClass
	public void sdfdsf() {
		System.out.println("This is TestNG BeforeClass");
	
	}
	
	
	@BeforeMethod
	public void sfsdsad() {
		System.out.println("This is TestNG BeforeMethod");
	
	}
	
	@AfterMethod
	public void aadasdasd() {
		System.out.println("This is TestNG AfterMethod");
	
	}
	
	@BeforeSuite
	public void vcbcvbcvb() {
		System.out.println("This is TestNG BeforeSuite");
	
	}
	
	@AfterSuite
	public void hthfghgh() {
		System.out.println("This is TestNG After Suite");
	
	}
	

}
