package TestNGframeworkExamples;

import org.testng.annotations.Test;

public class TestNGexamples {
	@Test
	public void secondTest() {
		System.out.println("This is second test");
	}

}
