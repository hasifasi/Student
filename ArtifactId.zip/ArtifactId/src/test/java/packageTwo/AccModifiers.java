package packageTwo;

public class AccModifiers {
	
	 void methodDefaultfromDiffPackage() {
		System.out.println("This is Default from different package");
	}

}
